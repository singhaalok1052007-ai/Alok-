VCPL ADVANCED ASSET TRACKER

FILES
- index.html: mobile-friendly asset dashboard.
- VCPL_Advanced_Asset_Tracker.xlsx: master Excel tracker.
- QR_Codes/: QR stickers for each sample asset.

HOW IT WORKS
1. Keep Excel as the master record.
2. The HTML dashboard can be hosted on any static website.
3. For true "scan QR -> open asset page", QR codes should point to the hosted page with the asset ID in the URL.
4. The included QR codes are intentionally offline-safe: scanning them displays the asset's core details directly.

NEXT STEP FOR LIVE QR
After you choose a hosting URL (for example a company website or GitHub Pages/Netlify), regenerate the QR codes with:
https://YOUR-HOST/asset/VCPL-0001
and make the page read the ID from the URL.
